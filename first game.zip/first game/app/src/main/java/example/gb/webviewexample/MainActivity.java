package example.gb.webviewexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ButtonBarLayout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {  
  
    @Override  
    protected void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.activity_main);  
        WebView mywebview = (WebView) findViewById(R.id.webView);  
        // mywebview.loadUrl("https://www.javatpoint.com/");  
  
        /*String data = "<html><body><h1>Hello, Javatpoint!</h1></body></html>"; 
        mywebview.loadData(data, "text/html", "UTF-8"); */  
  
        mywebview.loadUrl("file:///android_asset/index.html");  
    }  
}  